# Changelog

## v1.0.12

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.12>

## v1.0.11

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.11>

## v1.0.10

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.10>

## v1.0.9

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.9>

## v1.0.8

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.8>

## v1.0.7

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.7>

## v1.0.6

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.6>

## v1.0.5

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.5>

## v1.0.4

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.4>

## v1.0.3

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.3-corrected>

## v1.0.2

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.2>

## v1.0.2-0

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.2-0>

## 1.0.1

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.1>

## 1.0.0

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0>

## 1.0.0-9

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-9>

## 1.0.0-8

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-8>

## 1.0.0-7

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-7>

## 1.0.0-6

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-6>

## 1.0.0-5

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-5>

## 1.0.0-4

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-4>

## 1.0.0-3

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-3>

## 1.0.0-2

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-2>

## 1.0.0-1

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-1>

## 1.0.0-0

See <https://github.com/grafana/metrics-drilldown/releases/tag/v1.0.0-0>

## 0.1.0 (Unreleased)

Initial release.
